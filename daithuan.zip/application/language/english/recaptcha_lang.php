<?php
$lang['empty']			= "Bạn chưa nhập ReCaptcha ";
$lang['wrong']			= "Bạn đã nhập sai ReCaptcha";
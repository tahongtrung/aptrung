<?php


$lang['captcha_ads_label_post']  =   "Mã bảo vệ";

$lang['_valid_captcha_post_message_post']  =   "Mã bảo vệ không đúng";

$lang['username']   	=   "Tên user";
$lang['password']		=   "Mật khẩu";
$lang['passconf']		=   "Xác nhận Mật khẩu";
$lang['matches']		=   "Trường '%s' không khớp với trường '%s'.";
$lang['required']   	=   "Trường '%s' là bắt buộc.";
$lang['invalid-email']  =   "Email này không hợp lệ.";
?>
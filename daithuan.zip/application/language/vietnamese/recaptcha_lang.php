<?php
$lang['empty']			= "Bạn chưa nhập ReCaptcha ";
$lang['wrong']			= "Bạn đã nhập sai ReCaptcha";
$lang['captcha_ads_label_post']  =   "Mã bảo vệ";
$lang['_valid_captcha_post_message_post']  =   "Mã bảo vệ không đúng";
?>